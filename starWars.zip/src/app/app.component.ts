import {Component, OnInit} from '@angular/core';
import {Planet, PlanetsService} from "./services/planets.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  loading = false
  planets: Planet[] = []
  wishlist: string[] = []

  constructor(private planetsService: PlanetsService) {
  }

  ngOnInit() {
    this.fetchPlanets()
  }

  fetchPlanets() {
    this.loading = true
    this.planetsService.fetchPlanets()
      .subscribe(planets => {
        this.planets = planets.map((planet, index) => ({ ...planet, inList: false, id: index + 1 }));
        this.loading = false
      })
  }

  togglePlanet(planet: Planet) {
    planet.inList = !planet.inList
    const inList = this.wishlist.includes(planet.name)

    if (inList) {
      this.wishlist.forEach((item, index) => {
        if (planet.name === item) {
          this.wishlist.splice(index, 1)
        }
      })
    } else {
      this.wishlist.push(planet.name)
    }
  }
}
