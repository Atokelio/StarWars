import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {delay, pluck} from "rxjs/operators";

export interface Planet {
  id: number
  name: string
  diameter: number
  population: number
  inList: boolean
}

@Injectable({
  providedIn: 'root'
})

export class PlanetsService {

  constructor(private http: HttpClient) {
  }

  fetchPlanets(): Observable<Planet[]> {
    return this.http.get('https://swapi.dev/api/planets')
      .pipe(delay(1500))
      .pipe(pluck ('results'))
  }
}
