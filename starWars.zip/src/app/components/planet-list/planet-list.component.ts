import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {Planet} from "../../services/planets.service";

@Component({
  selector: 'app-planet-list',
  templateUrl: './planet-list.component.html',
  styleUrls: ['./planet-list.component.scss']
})
export class PlanetListComponent implements OnInit {
  @Output() onToggle: EventEmitter<Planet> = new EventEmitter<Planet>()
  @Input() planets: Planet[]

  constructor() {
  }

  ngOnInit(): void {
  }

  togglePlanet(planet: Planet) {
    this.onToggle.emit(planet)
  }
}
