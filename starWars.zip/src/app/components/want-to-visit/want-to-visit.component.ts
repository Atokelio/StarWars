import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-want-to-visit',
  templateUrl: './want-to-visit.component.html',
  styleUrls: ['./want-to-visit.component.scss']
})
export class WantToVisitComponent implements OnInit {

  @Input() wishlist: string[]

  constructor() { }

  ngOnInit(): void {
  }

}
